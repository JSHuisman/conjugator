## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
ggplot2::theme_set(ggplot2::theme_minimal())

## ----setup--------------------------------------------------------------------
#load package
library(conjugator)
#load example data
load('../data/DRT_example.rda')
DRT_example

## -----------------------------------------------------------------------------
estimate_conj_rate(DRT_example, "ASM")

## ----fig.asp = 0.5, fig.width = 8, out.width = "100%"-------------------------
library(ggplot2)
result_df <- estimate_conj_rate(DRT_example, c("SM", "ASM", "T_DR"))

ggplot(result_df, aes(y = estimate, x = ID, colour = method)) +
  geom_point(size = 2) +
  coord_trans(y = 'log10') +
  labs(x = 'Sample ID', y = 'Conjugation Rate Estimate', colour = 'Estimation Method')

## -----------------------------------------------------------------------------
library(tidyr)
wide_result_df <- pivot_wider(result_df, id_cols = 'ID', 
                              names_from = 'method', values_from = 'estimate')
wide_result_df

## -----------------------------------------------------------------------------
load('../data/TRT_example.rda')

estimate_crit_time(DRT_example, TRT_example, tol_factor = 10)

## -----------------------------------------------------------------------------
example_data <- cbind(DRT_example[, c('ID', 'psi.D', 'psi.R', 'psi.T', 'D.0', 'R.0')], 
                      'gamma.D' = c(1e-11, 1e-11, 1e-11), 
                      'gamma.T' = c(1e-11, 5e-11, 1e-9) )

estimate_crit_time(example_data, TRT = NULL, tol_factor = 10)

## ----fig.asp = 0.5, fig.width = 8, out.width = "100%"-------------------------
#multiplication factors to try
gamma_mult_factors <- 10**seq(-2, 5, 1)

scan_result <- scan_crit_time(DRT_example, tol_factor = 10, mult_seq = gamma_mult_factors)
scan_result

ggplot(scan_result) +
  geom_point(aes(y = min_tcrit, x = log10(mult_factor))) +
  facet_wrap(vars(ID)) +
  labs(x = 'Log ratio between gamma.T and gamma.D', y = 'Minimal Critical Time')

## ----fig.asp = 0.5, fig.width = 8, out.width = "100%"-------------------------
load('../data/growth_example.rda')

growth_df <- growth_example[1:15, c('Time_h', 'Donor_OD')]

growth_fit <- estimate_growth_rate(growth_df, t_start = 0, t_col = 'Time_h')
growth_plot <- get_growth_fit_for_plot(growth_df, t_col = 'Time_h', growth_fit)

ggplot() +
  geom_point(data = growth_df, aes(x = Time_h, y = Donor_OD)) +
  geom_line(data = growth_plot, aes(x = time, y = OD))

