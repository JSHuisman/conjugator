###########################################################
## Unit tests for the growth rate estimation
## Authors: Jana S. Huisman
###########################################################
context("Growth Rate Estimation")
library(conjugator)

###########################################################
test_that("estimate_growth_rate: example input data returns right result", {
  reference_result = data.frame(name = c('Donor_OD', 'Recipient_OD'),
                                carrying_cap = c(0.2903, 0.1613),
                                growth_rate = c(0.4903, 1.6970),
                                N0 = c(0.08252, 0.03780),
                                t_min = c(1.297, 1.297),
                                t_stat = c(3.863, 2.152))

  expect_equal(estimate_growth_rate(growth_example, t_start = 1, t_col = 'Time_h'), reference_result)
})


test_that("estimate_growth_rate: missing input data columns results in errors", {
  expect_silent(estimate_growth_rate(growth_example, t_start = 1, t_col = 'Time_h'))
  expect_error(estimate_growth_rate(growth_example, t_start = 1, t_col = 'time'), "not contain the time column")
  expect_error(estimate_growth_rate(growth_example[, 2:3], t_start = 1, t_col = 'Time_h'),
               "not contain the time column")
})

test_that("estimate_growth_rate: wrong input data columns results in errors", {
  bad_growth_example <- growth_example
  bad_growth_example[,3] <- as.character(bad_growth_example[,3])

  expect_error(estimate_growth_rate(bad_growth_example, t_start = 1, t_col = 'Time_h'), "non-numeric columns")
})

###########################################################

test_that("estimate_growth_rate: bad OD data is handled correctly", {
time = seq(0, 23.1, 0.1)
bad_OD = c(0.022490742,0.022051257,0.02960167,0.027647366,0.022637153,
           0.029372257,0.036074073,0.030885805,0.014078874,0.01623733,
           0.015660715,0.019343172,0.022298635,0.024529051,0.028848497,
           0.028326397,0.046813478,0.132054696,0.049759081,0.05702538,
           0.064624907,0.070679104,0.084481849,0.095414329,0.100948071,
           0.119646785,0.13673454,0.145948032,0.158267172,0.167926024,
           0.181016074,0.195122315,0.208734137,0.219084786,0.232272337,
           0.243304484,0.249089122,0.260210716,0.269470125,0.284622421,
           0.230977233,0.225993476,0.221003348,0.220695034,0.244067131,
           0.246414615,0.008667738,0.006758181,0.22597265,0.223142136,
           0.013598527,0.008863159,0.199031593,0.196927136,0.361142416,
           0.370488887,0.289889052,0.296770671,0.289768093,0.29455266,
           0.279146676,0.282489114,0.408488472,0.42417226,0.301719692,
           0.303113122,0.274413258,0.281794432,0.283214368,0.289790338,
           0.01590445,0.016684081,0.296736481,0.302279043,0.019452719,
           0.018970941,0.232554531,0.230499846,0.295475697,0.296975448,
           0.277190715,0.280113375,0.245299589,0.242790364,0.259269406,
           0.257520679,0.42852456,0.567928959,0.268539937,0.270803775,
           0.241569359,0.244376106,0.24429752,0.242668711,0.01770592,
           0.015867365,0.269433138,0.271132587,0.017838626,0.016083206,
           0.219448969,0.223059547,0.282003435,0.287673165,0.241138901,
           0.245012255,0.222503334,0.224306579,0.229185232,0.233240967,
           0.273580897,0.276444922,0.236904965,0.239118301,0.206460331,
           0.210326205,0.206678965,0.211307598,0.017597743,0.016950352,
           0.246738433,0.243242029,0.017848155,0.012957923,0.185651259,
           0.18798645,0.28762698,0.289288868,0.247036005,0.249944502,
           0.230666015,0.235062402,0.229062338,0.227775916,0.300890836,
           0.284715085,0.230557142,0.239523273,0.209416986,0.214451535,
           0.198530858,0.208640101,0.017345436,0.016663137,0.250734557,
           0.25269637,0.017326399,0.019089133,0.193999998,0.200693245,
           0.305024655,0.311000037,0.24802823,0.244589574,0.237607761,
           0.236329867,0.245981583,0.245927569,0.303882941,0.308119794,
           0.292663779,0.289692785,0.270953126,0.273692714,0.271741377,
           0.273469335,0.019255324,0.016926016,0.273547783,0.273994396,
           0.019030034,0.017086929,0.218515547,0.219323632,0.289504647,
           0.293034721,0.258591123,0.263675139,0.19347341,0.183830824,
           0.237142863,0.248468499,0.269315314,0.276406833,0.210953859,
           0.216719022,0.196702151,0.200379614,0.219694826,0.211450396,
           0.018279911,0.017756918,0.257478758,0.260224058,0.017517479,
           0.016798273,0.199108044,0.202284492,0.268854047,0.267518441,
           0.236730288,0.239416071,0.196884059,0.199209621,0.203236724,
           0.206160256,0.264007691,0.266618984,0.200098999,0.203539676,
           0.193795818,0.197238283,0.229534175,0.231587792,0.017436549,
           0.015764877,0.224202234,0.230917879,0.014425007,0.017329089,
           0.176717494,0.180541418,0.270088179,0.281680243,0.231409778,
           0.237919587,0.245232542,0.247633396,0.236399061,0.239594541,0.289826635,0.294571474)

  expect_error(estimate_growth_rate(data.frame(time = time, D = rep(NA, 232)),
                                    t_start = 1), "non-numeric column")
  expect_warning(estimate_growth_rate(data.frame(time = time, D = c(rep(NA, 20), bad_OD[21:232])),
                                    t_start = 1), "Unable to fit")
  expect_warning(estimate_growth_rate(data.frame(time = time, D = bad_OD), t_start = 1), "Unable to fit")
})

###########################################################


test_that("get_growth_fit_for_plot: missing input data columns results in errors", {
  growth_fit <- estimate_growth_rate(growth_example, t_start = 1, t_col = 'Time_h')

  expect_silent(get_growth_fit_for_plot(growth_example, t_col = 'Time_h', growth_fit))
  expect_error(get_growth_fit_for_plot(growth_example, t_col = 'time', growth_fit), "not contain the time column")

  bad_growth_fit <- growth_fit
  colnames(bad_growth_fit) <- rep('test', 6)
  expect_warning(get_growth_fit_for_plot(growth_example, t_col = 'Time_h', bad_growth_fit), 'The growth fit data is corrupted')
  expect_equal(suppressWarnings(get_growth_fit_for_plot(growth_example, t_col = 'Time_h', bad_growth_fit)), data.frame())
})



