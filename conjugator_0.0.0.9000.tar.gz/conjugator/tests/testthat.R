library(testthat)
library(conjugator)

test_check("conjugator")
